Hard.dat Rewrite v1.00

Released August 1st, 2002 by Dan Walma, aka redink1

Dedicated to mimifish, who was going to do this, but didn't have time
before he moved back to Taiwan.

Feel free to use this in any D-Mods you're working on.  It would be nice
if you included my name in the readme.txt to give me credit, but if you
forget I don't really mind :)

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
INTRO:

The original hard.dat file is pretty horrible.  Not only are there a lot
of holes in the hardness (i.e. gaps you can walk through), but it doesn't
re-use any of the hardness tiles... which is quite possible.

So, starting on July 27th, I started to re-write the entire file.  And
I managed to finish it today, August 1st.

This version should be pretty good for plugging into in-progress D-Mods.
However, if you stamped a lot of hardness tiles that weren't the old
geometric one... you'll have some problems.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
CREDITS:

Gary Hertel and WC: For WinDinkedit, which made browsing my often-corrupt
     hard.dat a breeze.
joshriot: For scolding me for not adding in the old geometric tiles.  At
     first I thought I couldn't add them in the same place they were with
     the original, but it proved to be possible.
Seth: For making the original hard.dat so horrible, I had to rewrite it :)

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STATS:

* Number of Hardness Tiles Used: 374
* Number of Hardness Tiles Free: 425
* Special Tiles (Number is the index where they're found)
  * All-Blank Hardness Tile:     1
  * All-Hard  Hardness Tile:     2
  * All-Soft  Hardness Tile:     3
  * New House Hardness Tiles:    4-34
  * Old Geometric Tiles:         745-799

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
DIFFERENCES:

Original: Crudely drawn boxes were used for most of the hardness (like for
rocks).

Rewrite: For the most part, the rewrite's hardness is much more exact than
the original.  For example, the hardness for most of the rocks is right on
the rocks, not in a box far away.  This might cause some problems where
Dink catches on the little 'grooves' in the hardness.  If you find any
specific areas where this happens, please let me know.


Original: The hardness was 'hollow', so you could walk on cliffs and such
if you fell through a 'hardness hole'.

Rewrite: Most of the hardness is now filled in.  That means the player
can't walk on f'ing cliffs any longer, or on water unless you specifically
want them to.


Original: Each Hardness Tile was only set to one bmp tile each.

Rewrite: Multiple bmp tiles use the same hardness tile.  For example, the
Grass/Darklands/Snow rocks all use the same hardness tiles.  All of the
'pit' tiles also share... like the water, hills, fire, etc. tilesets all
use basically the same hardness tiles.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
BLAH:

If you want to see what this hard.dat looks like in bmp format, check out
hard.bmp included with this zip.

If you want to see which hardness tiles are used for what bmp tiles, check
out hard.txt.

The files above were created using a very crappy perl script that I made.
I found it a lot easier to edit hard.dat while in bmp and txt formats, and
I have another perl script that writes a new hard.dat based on the
information in the bmp and txt files.

Unfortunatly, they don't work so well with the original hard.dat...
exporting seems fine, but creating a new hard.dat basically corrupts the
old one.  Its probably because of a questionable formula that messes up
the hard tile numbers that use bmp tiles greater than 512 or something...
not sure.

Oh, and Hex-Editing f*cking rules.  I mean... wow.  So far I've succeeded
in understanding (for the most part), BMP, hard.dat, save####.dat, and
map.dat mostly through hex-editing and looking for patterns.  Its so much
fun... UltraEdit-32 is simply the best.

But you kinda have to understand the hexidecimal format to understand
hex-editing... that stupid Discrete Structures math class is actually
really useful, surprisingly.

Oh, and the hardness tiles aren't in the best organization... but they
don't have to be.  Its actually kinda sloppy... and some tiles probably
could have been re-used if I really wanted to save space.  But... you
have 425 hardness tiles to make for yourself.  Thats more than enough :)